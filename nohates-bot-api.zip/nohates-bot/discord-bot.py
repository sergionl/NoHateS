# Discord API for NoHatES
import os
from dotenv import load_dotenv
from discord.ext import commands
import discord

load_dotenv()
BOT_TOKEN = os.getenv('DISCORD_TOKEN')

bot = commands.Bot(command_prefix="!", intents=discord.Intents.all())

@bot.event
async def on_ready():
    print('DISCORD BOT READY')

# Communication with NoHatES API
import requests
import json

@bot.command()
async def ayuda(ctx, *args):
    instructions = """Copyright (c) NoHatES.

Comandos disponibles:

    !inspeccionar
        Inspecciona los últimos 10 mensajes de un canal y brinda los 'id'
         de los mensajes y sus respectivos autores.

    !inspeccionar limite=15
        Inspecciona los últimos 15 mensajes de un canal y brinda los 'id'
         de los mensajes y sus respectivos autores.

    !visualizar 123456
        Visualiza un mensaje en base al 'id' (ej: 123456) del mensaje
"""

    await ctx.send(instructions)


@bot.command()
async def visualizar(ctx, *args):
    try:
        message_id = int(args[0])
    except:
        await ctx.send("El 'id' especificado no es válido")
        return

    try:
        message = await ctx.fetch_message(message_id)
        message = str(message.author) + ": " + str(message.content)
        await ctx.send(message)
    except:
        await ctx.send("No se encontró el 'id' especificado dentro del canal")

@bot.command()
async def inspeccionar(ctx, *args):
    url = "http://127.0.0.1:4201/test/"

    limit = 10
    try:
        if args[0].startswith('limite='):
            try:
                limit = int(args[0][7:])
                if limit <= 0:
                    raise Exception("Error: Menor o igual a 0")
            except:
                await ctx.send("El límite especificado no es un número entero positivo")
                return
    except:
        pass

    n_reported = 0
    channel_id = ctx.message.channel.id
    channel = bot.get_channel(channel_id)
    m = [message async for message in channel.history(limit=limit)]
    await ctx.send("Califican como Hate Speech los siguientes mensajes:")
    for w in m:
        # send content to NoHatES API
        data = { "text":  str(w.content) }
        # print('original: ', data)
        data = json.dumps(data)
        # print(data)
        r = requests.post(url=url, data=data)
        r.raise_for_status() 

        r = json.loads(r.text)

        # if r.text[1] == '1':
        if r["data"] == 1:
            n_reported += 1
            await ctx.send("mensaje: " + str(w.id) + " | autor: " + str(w.author))

    if n_reported == 0:
        await ctx.send("No se encontraron mensajes para reportar")

# No Hates API module (it's temporal here) [INI]
import random

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

def to_df(x, y):
    d = {"text": x, "label": y}
    return pd.DataFrame(d)

def split_3(df, test_size=0.2, valid_size=0.2):
    _df = df.copy().sample(frac=1).reset_index()
    _df = _df[["text", "label"]]
    #
    x = _df["text"].copy()
    y = _df["label"].copy()
    #split train-test
    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=test_size, stratify=y)
    # split train-valid
    x, y = x_train, y_train
    x_train, x_valid, y_train, y_valid = train_test_split(x, y, test_size=valid_size, stratify=y)
    return to_df(x_train, y_train), to_df(x_valid, y_valid), to_df(x_test, y_test)

def api_load_samples():
    tname_data = "hsd_merge_cleaned_lowered"
    data = pd.read_csv(f"{tname_data}.csv")

    train, valid, test = split_3(data)

    test_sentences = list(test["text"].values)
    test_labels = list(test["label"].values)

    return test_sentences, test_labels

api_test_s, api_test_l = api_load_samples()

@bot.command()
async def ejemplos(ctx, *args):
    limit = 10
    try:
        if args[0].startswith('n='):
            try:
                limit = int(args[0][2:])
            except:
                await ctx.send("El límite especificado no es un número entero")
    except:
        await ctx.send("No se especificó el limite, se considera que n=10")

    print(len(api_test_s))
    api_test_s2 = [v for i, v in enumerate(api_test_s)  if api_test_l[i] == 1]
    print(len(api_test_s2))
    # samples = random.choices(api_test_s, k=limit)
    samples = random.choices(api_test_s2, k=limit)
    for i in range(limit):
        # print(samples[i])
        await ctx.send(samples[i])

# No Hates API module (it's temporal here) [END]

bot.run(BOT_TOKEN)


